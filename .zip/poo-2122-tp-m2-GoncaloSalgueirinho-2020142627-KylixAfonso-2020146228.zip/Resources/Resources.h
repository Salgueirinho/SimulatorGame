#ifndef RESOURCES_H
#define RESOURCES_H

class Resources {
	public:
		int	iron = 0;
		int	steel = 0;
		int	coal = 0;
		int	wood = 0;
		int	wood_planks = 0;
		int	electricity = 0;
		int	cash = 0;
};

#endif
