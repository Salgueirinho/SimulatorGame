#include "BuildingX.h"

void BuildingX::work(Resources& resources, int day, int n)
{
  (void) resources;
  (void) day;
  (void) n;
}